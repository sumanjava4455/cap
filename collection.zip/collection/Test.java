package com.collection;

import java.util.ArrayList;

import java.util.Comparator;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		
		List<Address> address1=new ArrayList<>();
		address1.add(new Address(1,"karappakam","Chennai"));
		address1.add(new Address(2,"kalyan nagar","kanchipuram"));
		List<Address> address2=new ArrayList<>();
		address2.add(new Address(3,"jaya nagar","tiruvallur"));
		address2.add(new Address(4,"govindaswamy ","Madurai"));
		List<Address> address3=new ArrayList<>();
		address3.add(new Address(5,"sri nagar","Trichy"));
		address3.add(new Address(6,"mg road","vellore "));
		List<Employee> empList=new ArrayList<>();
		empList.add(new Employee(1,"vishnu","vardhan",30000,new Department(10, "Finance", "Chennai"),address1));
		empList.add(new Employee(2,"sai","ram",35000,new Department(20, "Networks", "tiruvallur"),address2));
		empList.add(new Employee(3,"sri","krishna",40000,new Department(30, "ENGNE", "Madurai"),address3));
		
		Comparator<Employee> sortByEmpid=new Comparator<Employee>() {
			
			@Override
			public int compare(Employee o1, Employee o2) {
				if(o1.getEmployeeId()>o2.getEmployeeId())
					return 1;
				else if(o1.getEmployeeId()<o2.getEmployeeId())
					return -1;
				else
				return 0;
			}
		};
		Comparator<Employee> sortByFirstname=new Comparator<Employee>() {
			
			@Override
			public int compare(Employee o1, Employee o2) {
				
				return o1.getFirstName().compareTo(o2.getFirstName());
			}
		};
		
		Comparator<Employee> sortBySalary=new Comparator<Employee>() {
			
			
			public int compare(Employee o1, Employee o2) {
				if(o1.getSalary()>o2.getSalary())
					return 1;
				else if(o1.getSalary()<o2.getSalary())
					return -1;
				else
				return 0;
			}
		};
Comparator<Employee> sortByDeptLoc=new Comparator<Employee>() {
			
			
			public int compare(Employee o1, Employee o2) {
				
				return o1.getDepartment().getLocation().compareTo(o2.getDepartment().getLocation());
			}
		};
		
		//Collections.sort(empList,sortByEmpid);
		//Collections.sort(empList, sortByFirstname);
		//Collections.sort(empList,sortBySalary);
		//Collections.sort(empList,sortByDeptLoc);
		for (Employee employee : empList) {
			
			System.out.println("EmployeeId: "+employee.getEmployeeId()+" Firstname: "+employee.getFirstName()+" LastName: "+employee.getLastName()+" Salary: "+employee.salary);
			Department dept=new Department();
			dept=employee.getDepartment();
			System.out.print("Departname ID:"+dept.getDeptId()+" Dept name: "+dept.getDeptName()+" Location: "+dept.getLocation()+" Address: [");
			List<Address> ad=new ArrayList<>();
			ad=employee.getAddress();
			for(Address adr:ad)
			{
				System.out.print("Address Id: "+adr.getAddressId()+" StreetName: "+adr.getStreetName()+" City: "+adr.getCity());
			}
			System.out.println("]");
		}
	}

}
