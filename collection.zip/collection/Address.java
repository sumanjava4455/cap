package com.collection;

public class Address {
	int addressId;
	String streetName;
	String city;
	public Address(int i, String string, String string2) {
		this.addressId=i;
		this.streetName=string;
		this.city=string2;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

}
