package org.cap.model;

import java.util.List;

public class Employee {
	private String employeeId;
	private String firstName;
	private String lstName;
	private String salary;
	private List<Address> address;
	private Department department;
	
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLstName() {
		return lstName;
	}
	public void setLstName(String lstName) {
		this.lstName = lstName;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String employeeId, String firstName, String lstName, String salary, List<Address> address,
			Department department) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lstName = lstName;
		this.salary = salary;
		this.address = address;
		this.department = department;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lstName=" + lstName + ", salary="
				+ salary + ", address=" + address + ", department=" + department + "]";
	}
	
	
}
