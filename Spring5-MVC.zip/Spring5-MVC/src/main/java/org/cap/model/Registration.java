package org.cap.model;

import java.time.LocalDate;

public class Registration {
	
	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String mobile;
	private String emailId;
	private String password;
	private LocalDate dateOfJoining;
	private String qualification;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public Registration(String firstName, String lastName, String address, String city, String mobile, String emailId,
			String password, LocalDate dateOfJoining, String qualification) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.mobile = mobile;
		this.emailId = emailId;
		this.password = password;
		this.dateOfJoining = dateOfJoining;
		this.qualification = qualification;
	}
	public Registration() {
		super();
	}
	@Override
	public String toString() {
		return "Resgistration [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", city="
				+ city + ", mobile=" + mobile + ", emailId=" + emailId + ", password=" + password + ", dateOfJoining="
				+ dateOfJoining + ", qualification=" + qualification + "]";
	}
	
	
	

}
