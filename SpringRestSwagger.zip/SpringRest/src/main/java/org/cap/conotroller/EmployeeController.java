package org.cap.conotroller;

//package org.cap.conotroller;

import java.util.List;

import org.cap.dao.IEmployeeDao;
import org.cap.dao.IProductDao;
import org.cap.model.Employee;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	
	@Autowired
	private IEmployeeDao employeeDao;
	
	
	//@PostMapping("/product")
	//@PutMapping("/product")
	//@PatchMapping("/product")
	
	
	@DeleteMapping("/employees/{employeeId}")
	public ResponseEntity<List<Employee>> deleteEmployee(
			@PathVariable("employeeId") Integer employeeId){
		List<Employee> employees=employeeDao.deleteEmployee(employeeId);
		
		if(employees==null) {
			return new ResponseEntity("Sorry! Product Id not exists! Deletion Error!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	
	@GetMapping("/employees")
	@ApiOperation(nickname = "AllEmployees",value = "Fetch All Employees from DB.")
	@ApiImplicitParams({
		@ApiImplicitParam(value = "employeeId",dataType = "Integer")
	})
	
	public ResponseEntity<List<Employee>> getAllEmployees(){
		List<Employee> employees=employeeDao.getAllEmployees();
		
		if(employees==null || employees.isEmpty() ) {
			return new ResponseEntity("Sorry! No Items Available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	@GetMapping("/employees/{employeeId}")
	@ApiOperation(nickname = "AllEmployees",value = "Find Employees from DB.")
	@ApiImplicitParams({
		@ApiImplicitParam(value = "employeeId",dataType = "Integer")
	})
	public ResponseEntity<Employee> findEmployee(
			@PathVariable("employeeId") Integer employeeId ){
		Employee employee=employeeDao.findEmployee(employeeId);
		
		if(employee==null ) {
			return new ResponseEntity("Sorry!Product Id Not Found!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}
	
}

