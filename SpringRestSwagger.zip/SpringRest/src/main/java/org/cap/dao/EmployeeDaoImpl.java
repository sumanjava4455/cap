package org.cap.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Address;
import org.cap.model.Department;
import org.cap.model.Employee;
import org.cap.model.Manufacturer;
import org.cap.model.Product;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	private static AtomicInteger employeeId=new AtomicInteger(1234);
	private static AtomicInteger addressId=new AtomicInteger(1);
	private static AtomicInteger departmentId=new AtomicInteger(567);
	private static List<Employee> db=getDummyDB(); 
	
	
	private static List<Employee> getDummyDB(){
		List<Employee> employees=new ArrayList<Employee>();
			Address address1=new Address(addressId.getAndIncrement(), "Street1", "city1");
			//Address address2=new Address(addressId.getAndIncrement(), "Street2", "city2");
			
			Department dept1 = new Department(departmentId.getAndIncrement(),"dep_name1","location1");
			Department dept2 = new Department(departmentId.getAndIncrement(),"dep_name2","location2");
			
			employees.add(new Employee(employeeId.getAndIncrement(),"Hari","V",45000.00, address1,dept1));
			employees.add(new Employee(employeeId.getAndIncrement(), "Siva","V", 23000.00, address1,dept2));
			
			Address address2=new Address(addressId.getAndIncrement(), "Street2", "city2");
			//Address address4=new Address(addressId.getAndIncrement(), "Street2", "city2");
			
			Department dept3 = new Department(departmentId.getAndIncrement(),"dep_name3","location3");
			Department dept4 = new Department(departmentId.getAndIncrement(),"dep_name4","location4");
			
			employees.add(new Employee(employeeId.getAndIncrement(), "Sai", "V", 30000.00, address2,dept3));
			employees.add(new Employee(employeeId.getAndIncrement(), "Sravya", "V", 67000.00, address2,dept4));
			
			
		
		return employees;
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return db;
	}

	@Override
	public Employee findEmployee(Integer employeeId) {
		// TODO Auto-generated method stub
		for(Employee employee:db) {
			if(employee.getEmployeeId()==employeeId)
				return employee;
		}
		return null;
	}

	@Override
	public List<Employee> deleteEmployee(Integer employeeId) {
		// TODO Auto-generated method stub
		boolean flag=false;
		Iterator<Employee> iterator = db.iterator();
		while(iterator.hasNext()) {
			Employee employee= iterator.next();
			if(employee.getEmployeeId()==employeeId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		if(flag)
			return db;
		else
			return null;
	}

}
